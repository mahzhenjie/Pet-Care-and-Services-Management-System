﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.RefreshButton = New System.Windows.Forms.Button()
        Me.SearchTextBox = New System.Windows.Forms.TextBox()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.RoomID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoomNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoomType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PricePerDay = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Edit = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Delete = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.AddBoardingRoomButton = New System.Windows.Forms.Button()
        Me.StatusComboBox = New System.Windows.Forms.ComboBox()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.Panel1.Controls.Add(Me.StatusComboBox)
        Me.Panel1.Controls.Add(Me.AddBoardingRoomButton)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.RefreshButton)
        Me.Panel1.Controls.Add(Me.SearchTextBox)
        Me.Panel1.Controls.Add(Me.TitleLabel)
        Me.Panel1.ForeColor = System.Drawing.Color.SaddleBrown
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 580)
        Me.Panel1.TabIndex = 4
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(239, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RoomID, Me.RoomNumber, Me.RoomType, Me.PricePerDay, Me.Status, Me.Edit, Me.Delete})
        Me.DataGridView1.GridColor = System.Drawing.Color.Sienna
        Me.DataGridView1.Location = New System.Drawing.Point(25, 97)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(868, 455)
        Me.DataGridView1.TabIndex = 7
        '
        'RefreshButton
        '
        Me.RefreshButton.BackColor = System.Drawing.Color.SaddleBrown
        Me.RefreshButton.Font = New System.Drawing.Font("Lucida Sans Unicode", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RefreshButton.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.RefreshButton.Location = New System.Drawing.Point(613, 65)
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(137, 27)
        Me.RefreshButton.TabIndex = 3
        Me.RefreshButton.Text = "Refresh"
        Me.RefreshButton.UseVisualStyleBackColor = False
        '
        'SearchTextBox
        '
        Me.SearchTextBox.Font = New System.Drawing.Font("Lucida Sans Unicode", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchTextBox.ForeColor = System.Drawing.Color.Sienna
        Me.SearchTextBox.Location = New System.Drawing.Point(24, 64)
        Me.SearchTextBox.Name = "SearchTextBox"
        Me.SearchTextBox.Size = New System.Drawing.Size(398, 27)
        Me.SearchTextBox.TabIndex = 1
        Me.SearchTextBox.Text = "Search boarding room..."
        Me.SearchTextBox.UseWaitCursor = True
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Font = New System.Drawing.Font("Lucida Sans Unicode", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleLabel.Location = New System.Drawing.Point(20, 15)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(427, 34)
        Me.TitleLabel.TabIndex = 0
        Me.TitleLabel.Text = "Boarding Room Management"
        '
        'RoomID
        '
        Me.RoomID.FillWeight = 135.0!
        Me.RoomID.HeaderText = "Room ID"
        Me.RoomID.Name = "RoomID"
        Me.RoomID.Width = 135
        '
        'RoomNumber
        '
        Me.RoomNumber.HeaderText = "Room Number"
        Me.RoomNumber.Name = "RoomNumber"
        Me.RoomNumber.Width = 130
        '
        'RoomType
        '
        Me.RoomType.HeaderText = "Room Type"
        Me.RoomType.Name = "RoomType"
        Me.RoomType.Width = 160
        '
        'PricePerDay
        '
        Me.PricePerDay.FillWeight = 150.0!
        Me.PricePerDay.HeaderText = "Price Per Day"
        Me.PricePerDay.Name = "PricePerDay"
        '
        'Status
        '
        Me.Status.FillWeight = 180.0!
        Me.Status.HeaderText = "Status"
        Me.Status.Name = "Status"
        Me.Status.Width = 180
        '
        'Edit
        '
        Me.Edit.HeaderText = "Edit"
        Me.Edit.Name = "Edit"
        Me.Edit.Width = 60
        '
        'Delete
        '
        Me.Delete.HeaderText = "Delete"
        Me.Delete.Name = "Delete"
        Me.Delete.Text = "[Delete]"
        Me.Delete.Width = 60
        '
        'AddBoardingRoomButton
        '
        Me.AddBoardingRoomButton.BackColor = System.Drawing.Color.SaddleBrown
        Me.AddBoardingRoomButton.Font = New System.Drawing.Font("Lucida Sans Unicode", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddBoardingRoomButton.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.AddBoardingRoomButton.Location = New System.Drawing.Point(756, 65)
        Me.AddBoardingRoomButton.Name = "AddBoardingRoomButton"
        Me.AddBoardingRoomButton.Size = New System.Drawing.Size(137, 27)
        Me.AddBoardingRoomButton.TabIndex = 8
        Me.AddBoardingRoomButton.Text = "+Room"
        Me.AddBoardingRoomButton.UseVisualStyleBackColor = False
        '
        'StatusComboBox
        '
        Me.StatusComboBox.FormattingEnabled = True
        Me.StatusComboBox.Location = New System.Drawing.Point(520, 67)
        Me.StatusComboBox.Name = "StatusComboBox"
        Me.StatusComboBox.Size = New System.Drawing.Size(87, 24)
        Me.StatusComboBox.TabIndex = 11
        Me.StatusComboBox.Text = "Status"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(942, 603)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents RefreshButton As System.Windows.Forms.Button
    Friend WithEvents SearchTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents RoomID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RoomNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RoomType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PricePerDay As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Edit As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Delete As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents AddBoardingRoomButton As System.Windows.Forms.Button
    Friend WithEvents StatusComboBox As System.Windows.Forms.ComboBox

End Class
