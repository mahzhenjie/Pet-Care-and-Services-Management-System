﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PetLabel = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.AddVideoButton = New System.Windows.Forms.Button()
        Me.PetVideosLabel = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.VideoID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BoardingBookingID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VideoURL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UploadDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Edit = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Delete = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(216, Byte), Integer), CType(CType(194, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.CloseButton)
        Me.Panel1.Controls.Add(Me.AddVideoButton)
        Me.Panel1.Controls.Add(Me.PetVideosLabel)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.TitleLabel)
        Me.Panel1.ForeColor = System.Drawing.Color.SaddleBrown
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 580)
        Me.Panel1.TabIndex = 4
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(111, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(55, Byte), Integer))
        Me.Panel2.Controls.Add(Me.PetLabel)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Location = New System.Drawing.Point(24, 55)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(445, 138)
        Me.Panel2.TabIndex = 16
        '
        'PetLabel
        '
        Me.PetLabel.AutoSize = True
        Me.PetLabel.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PetLabel.ForeColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(184, Byte), Integer))
        Me.PetLabel.Location = New System.Drawing.Point(13, 11)
        Me.PetLabel.Name = "PetLabel"
        Me.PetLabel.Size = New System.Drawing.Size(40, 21)
        Me.PetLabel.TabIndex = 8
        Me.PetLabel.Text = "Pet:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(184, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(13, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 21)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Room:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(184, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(13, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 21)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Start Date:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(184, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(13, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 21)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "End Date:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(184, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(13, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 21)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Status:"
        '
        'CloseButton
        '
        Me.CloseButton.BackColor = System.Drawing.Color.SaddleBrown
        Me.CloseButton.Font = New System.Drawing.Font("Lucida Sans Unicode", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CloseButton.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.CloseButton.Location = New System.Drawing.Point(755, 550)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(137, 27)
        Me.CloseButton.TabIndex = 15
        Me.CloseButton.Text = "Close"
        Me.CloseButton.UseVisualStyleBackColor = False
        '
        'AddVideoButton
        '
        Me.AddVideoButton.BackColor = System.Drawing.Color.SaddleBrown
        Me.AddVideoButton.Font = New System.Drawing.Font("Lucida Sans Unicode", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddVideoButton.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.AddVideoButton.Location = New System.Drawing.Point(612, 550)
        Me.AddVideoButton.Name = "AddVideoButton"
        Me.AddVideoButton.Size = New System.Drawing.Size(137, 27)
        Me.AddVideoButton.TabIndex = 14
        Me.AddVideoButton.Text = "+Video"
        Me.AddVideoButton.UseVisualStyleBackColor = False
        '
        'PetVideosLabel
        '
        Me.PetVideosLabel.AutoSize = True
        Me.PetVideosLabel.Font = New System.Drawing.Font("Lucida Sans Unicode", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PetVideosLabel.Location = New System.Drawing.Point(20, 200)
        Me.PetVideosLabel.Name = "PetVideosLabel"
        Me.PetVideosLabel.Size = New System.Drawing.Size(166, 34)
        Me.PetVideosLabel.TabIndex = 13
        Me.PetVideosLabel.Text = "Pet Videos"
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(239, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.VideoID, Me.BoardingBookingID, Me.VideoURL, Me.UploadDate, Me.Description, Me.Edit, Me.Delete})
        Me.DataGridView1.GridColor = System.Drawing.Color.Sienna
        Me.DataGridView1.Location = New System.Drawing.Point(24, 235)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(868, 309)
        Me.DataGridView1.TabIndex = 7
        '
        'VideoID
        '
        Me.VideoID.FillWeight = 135.0!
        Me.VideoID.HeaderText = "Video ID"
        Me.VideoID.Name = "VideoID"
        Me.VideoID.Width = 135
        '
        'BoardingBookingID
        '
        Me.BoardingBookingID.FillWeight = 135.0!
        Me.BoardingBookingID.HeaderText = "BoardingBookingID"
        Me.BoardingBookingID.Name = "BoardingBookingID"
        Me.BoardingBookingID.Width = 135
        '
        'VideoURL
        '
        Me.VideoURL.FillWeight = 135.0!
        Me.VideoURL.HeaderText = "VideoURL"
        Me.VideoURL.Name = "VideoURL"
        Me.VideoURL.Width = 135
        '
        'UploadDate
        '
        Me.UploadDate.FillWeight = 150.0!
        Me.UploadDate.HeaderText = "UploadDate"
        Me.UploadDate.Name = "UploadDate"
        '
        'Description
        '
        Me.Description.FillWeight = 200.0!
        Me.Description.HeaderText = "Description"
        Me.Description.Name = "Description"
        Me.Description.Width = 200
        '
        'Edit
        '
        Me.Edit.HeaderText = "Edit"
        Me.Edit.Name = "Edit"
        Me.Edit.Width = 60
        '
        'Delete
        '
        Me.Delete.HeaderText = "Delete"
        Me.Delete.Name = "Delete"
        Me.Delete.Text = "[Delete]"
        Me.Delete.Width = 60
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Font = New System.Drawing.Font("Lucida Sans Unicode", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleLabel.Location = New System.Drawing.Point(20, 15)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(376, 34)
        Me.TitleLabel.TabIndex = 0
        Me.TitleLabel.Text = "Boarding Booking Details"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(942, 603)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TitleLabel As System.Windows.Forms.Label
    Friend WithEvents PetLabel As System.Windows.Forms.Label
    Friend WithEvents VideoID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BoardingBookingID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VideoURL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UploadDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Edit As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents Delete As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents PetVideosLabel As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents AddVideoButton As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel

End Class
